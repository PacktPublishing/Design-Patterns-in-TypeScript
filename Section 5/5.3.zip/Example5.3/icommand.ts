export interface ICommand {
    execute(): Promise<any>;
}