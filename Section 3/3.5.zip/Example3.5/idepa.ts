export interface IDepA {
    doA(): void;
}