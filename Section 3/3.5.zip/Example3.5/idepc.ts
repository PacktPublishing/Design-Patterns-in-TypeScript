export interface IDepC {
    doC(): void;
}