export const TYPES = {
    IDepA: Symbol.for("IDepA"),
    IDepB: Symbol.for("IDepB"),
    IDepC: Symbol.for("IDepC")
}