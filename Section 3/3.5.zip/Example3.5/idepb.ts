export interface IDepB {
    doB(): void;
}