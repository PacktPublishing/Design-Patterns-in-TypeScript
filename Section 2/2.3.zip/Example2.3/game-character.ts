export interface GameCharacter {
    strength: number;
    dexterity: number;
    health: number;
    magic: number;
}