export interface Country {
    name: string;
    capital: string;
    currency: string;
}